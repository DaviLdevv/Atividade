document.addEventListener('DOMContentLoaded', function() {
    const botaoTema = document.createElement('button');
    botaoTema.className = 'botao-tema';
    document.body.appendChild(botaoTema);
    
    const botaoPainel = document.createElement('button');
    botaoPainel.className = 'botao-painel';
    botaoPainel.innerHTML = '☰ Menu';
    document.body.appendChild(botaoPainel);
    
    const temaSalvo = localStorage.getItem('tema');
    
    if (temaSalvo === 'claro') {
        document.body.classList.add('tema-claro');
        botaoTema.textContent = '🌞 Modo Claro';
    } else {
        document.body.classList.remove('tema-claro');
        botaoTema.textContent = '🌙 Modo Escuro';
    }
    
    botaoTema.addEventListener('click', function() {
        document.body.classList.toggle('tema-claro');
        
        if (document.body.classList.contains('tema-claro')) {
            localStorage.setItem('tema', 'claro');
            botaoTema.textContent = '🌞 Modo Claro';
        } else {
            localStorage.setItem('tema', 'escuro');
            botaoTema.textContent = '🌙 Modo Escuro';
        }
    });
    
    botaoPainel.addEventListener('click', function() {
        document.getElementById('menu').classList.toggle('painel-aberto');
        document.body.classList.toggle('menu-aberto');
    });
    
    const linksMenu = document.querySelectorAll('.listaMenu a');
    linksMenu.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                document.getElementById('menu').classList.remove('painel-aberto');
                document.body.classList.remove('menu-aberto');
            }
        });
    });
});

document.addEventListener('click', function(e) {
    const menu = document.getElementById('menu');
    const botaoAbrir = document.querySelector('.botao-painel');
    
    if (window.innerWidth <= 768 && 
        menu.classList.contains('painel-aberto') &&
        !menu.contains(e.target) &&
        e.target !== botaoAbrir &&
        !botaoAbrir.contains(e.target)) {
        menu.classList.remove('painel-aberto');
        document.body.classList.remove('menu-aberto');
    }
});

        const tarefaInput = document.getElementById('tarefaInput');
        const adicionarBtn = document.getElementById('adicionarBtn');
        const listaTarefas = document.getElementById('listaTarefas');
        const feedbackEl = document.getElementById('feedback');
        
        let tarefas = [];
        
        document.addEventListener('DOMContentLoaded', () => {
            carregarTarefas();
            listarTarefas();
            
            adicionarBtn.addEventListener('click', adicionarTarefa);
            tarefaInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') adicionarTarefa();
            });
        });
        
        function adicionarTarefa() {
            const texto = tarefaInput.value.trim();
            
            if (texto === '') {
                mostrarFeedback('DIGITE UMA TAREFA VÁLIDA!', 'error');
                return;
            }
            
            if (tarefas.some(tarefa => tarefa.texto.toLowerCase() === texto.toLowerCase())) {
                mostrarFeedback('TAREFA JÁ EXISTE!', 'error');
                return;
            }
            
            tarefas.push({ texto });
            
            tarefaInput.value = '';
            
            listarTarefas();
            salvarLocalStorage();
            
            mostrarFeedback('TAREFA ADICIONADA! ✅', 'success');
        }
        
        function listarTarefas() {
            listaTarefas.innerHTML = '';
            
            if (tarefas.length === 0) {
                listaTarefas.innerHTML = '<div class="lista-vazia">NENHUMA TAREFA CADASTRADA. ADICIONE UMA NOVA TAREFA!</div>';
                return;
            }
            
            tarefas.forEach((tarefa, index) => {
                const li = document.createElement('li');
                li.className = 'tarefa-item';
                
                li.innerHTML = `
                    <span class="tarefa-texto">${tarefa.texto}</span>
                    <div class="botoes-acao">
                        <button class="btn btn-editar" onclick="editarTarefa(${index})">EDITAR</button>
                        <button class="btn btn-excluir" onclick="removerTarefa(${index})">EXCLUIR</button>
                    </div>
                `;
                
                listaTarefas.appendChild(li);
            });
        }
        
        function removerTarefa(index) {
            tarefas.splice(index, 1);
            
            listarTarefas();
            salvarLocalStorage();
            
            mostrarFeedback('TAREFA REMOVIDA!', 'success');
        }
        
        function editarTarefa(index) {
            const tarefaAtual = tarefas[index];
            
            tarefaInput.value = tarefaAtual.texto;
            tarefaInput.focus();
            
            tarefas.splice(index, 1);
            
            listarTarefas();
            salvarLocalStorage();
            
            mostrarFeedback('TAREFA PRONTA PARA EDIÇÃO!', 'success');
        }
        
        function salvarLocalStorage() {
            localStorage.setItem('tarefas', JSON.stringify(tarefas));
        }
        
        function carregarTarefas() {
            const tarefasSalvas = localStorage.getItem('tarefas');
            
            if (tarefasSalvas) {
                tarefas = JSON.parse(tarefasSalvas);
            }
        }
        
        function mostrarFeedback(mensagem, tipo) {
            feedbackEl.textContent = mensagem;
            feedbackEl.className = `feedback ${tipo} show`;
            
            setTimeout(() => {
                feedbackEl.classList.remove('show');
            }, 3000);
        }